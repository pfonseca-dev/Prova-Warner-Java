
import java.util.*;
import java.io.*;
/**
 *
 * @author aluno9
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o ID: ");
        String id = sc.nextLine();
        System.out.println("Digite a senha: ");
        String senha = sc.nextLine();

        System.out.println("Login realizado\n");

        Venda v = new Venda();

        try {
            File arquivo = new File("produtos.txt");
            Scanner leitor = new Scanner(arquivo);

            while (leitor.hasNextLine()) {
                String linha = leitor.nextLine();
                String[] partes = linha.split(",");

                String nome = partes[0];
                double preco = Double.parseDouble(partes[1]);

                Produto p = new Produto(nome, preco);
                v.addProduto(p);
            }

            leitor.close();

        } catch (FileNotFoundException e) {
            System.out.println("Arquivo não encontrado!");
            return;
        }

        System.out.println("Itens carregados do arquivo:");
        v.mostrarItens();

        double total = v.calcularTotal();
        System.out.println("Total: R$ " + total);

        System.out.print("Valor recebido: ");
        double recebido = sc.nextDouble();

        double troco = recebido - total;
        System.out.println("Troco: R$ " + troco);

        System.out.println("\nVenda finalizada!");

        sc.close();

    }

}
