

import java.util.*;
/**
 *
 * @author aluno9
 */
public class Venda {
    ArrayList<Produto> itens = new ArrayList<>();

    public void addProduto(Produto p){
        itens.add(p);
    }

    public void mostrarItens(){
        for(Produto p : itens){
            System.out.println("Item: " + p.nome + " - R$: " + p.preco);
        }
    }

    public double calcularTotal(){
        double total = 0;
        for (Produto p : itens){
            total += p.preco;
        }
        return total;
    }
}
