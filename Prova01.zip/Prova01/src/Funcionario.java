/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author aluno9
 */
public class Funcionario {
    int id;
    double senha;

    public Funcionario(int id, double senha){
        this.id = id;
        this.senha = senha;
    }
}
