public class Empregado {
    String nome;
    double cpf;
    double salario;

    public Empregado(String nome, double cpf , double salario){
        this.cpf = cpf;
        this.salario = salario;
        this.nome = nome;
    }
}