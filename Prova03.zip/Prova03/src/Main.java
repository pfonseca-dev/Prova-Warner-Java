import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {

        Scanner sc = new Scanner(System.in);
        ArrayList<Empregado> empregadoArrayList = new ArrayList<>();

        BufferedWriter criar = new BufferedWriter(new FileWriter("arquivo.txt"));

        String nome;
        double salario;
        double cpf;
        int i = 0;

        for(int a = 0; a <= 5 ; a++){
            System.out.println("############");
            System.out.println("digite os dados do funcionario");
            System.out.println("############");
            System.out.println("digite o nome");
            nome = sc.nextLine();

            System.out.println("############");
            System.out.println("digite o salario");
            salario = sc.nextDouble();

            System.out.println("############");
            System.out.println("digite o cpf");
            cpf = sc.nextDouble();
            sc.nextLine();

            empregadoArrayList.add(new Empregado(nome,cpf,salario));

            criar.write(empregadoArrayList.get(i).nome + " ; ");
        }

        criar.close();

        System.out.printf("digite um cpf para deletar ");
        double valor = sc.nextFloat();

        double acharValor;

        for(int a = 0 ; a <= 5; a++){
            acharValor = empregadoArrayList.get(a).cpf;

            if (acharValor == valor){
                empregadoArrayList.remove(valor);
                break;
            }
        }

        System.out.println("removido com sucesso");

        for(i = 0 ; i <= 5 ; i++ ){
            System.out.printf(empregadoArrayList.get(i).nome);
        }
    }
}
}