package prova;

import java.util.Scanner;

public class Prova {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Sistema system = new Sistema();

        int op;
        label19:
        do {
            System.out.println("==== Cadastro =====");
            System.out.println("1- Cadastrar Aluno: ");
            System.out.println("2- Listar Aluno");
            System.out.println("0 - Sair");
            System.out.print("Opcao: ");
            op = sc.nextInt();
            sc.nextLine();
            switch (op) {
                case 0:
                    System.out.println("Saindo manualmente...");
                    break;
                case 1:
                    System.out.print("RA: ");
                    int ra = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nome: ");
                    String aluno = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Celular: ");
                    String celular = sc.nextLine();
                    Aluno a = new Aluno(ra, aluno, email, celular);
                    if (!system.cadastro(a)) {
                        break label19;
                    }
                    break;
                case 2:
                    system.listar();
            }
        } while(op != 0);

        sc.close();
    }
}