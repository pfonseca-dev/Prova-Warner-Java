package prova;

public class Aluno {
    int ra;
    String aluno;
    String email;
    String celular;

    public Aluno(int ra, String aluno, String email, String celular) {
        this.ra = ra;
        this.aluno = aluno;
        this.email = email;
        this.celular = celular;
    }
}