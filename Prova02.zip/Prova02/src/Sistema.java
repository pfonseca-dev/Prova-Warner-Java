package prova;

import java.util.ArrayList;

public class Sistema {
    ArrayList<Aluno> alunos = new ArrayList();

    public Sistema() {
    }

    public boolean cadastro(Aluno a) {
        if (a.ra <= 0) {
            System.out.println("RA negativo, fechando sistema...");
            return false;
        } else {
            this.alunos.add(a);
            System.out.println("Aluno Cadastrado!\n\n");
            return true;
        }
    }

    public void listar() {
        for(int i = 0; i < this.alunos.size(); ++i) {
            Aluno a = (Aluno)this.alunos.get(i);
            System.out.println(i + 1 + "- RA: " + a.ra + "| Nome: " + a.aluno + "| E-mail: " + a.email + "| Celular: " + a.celular);
        }

    }
}
